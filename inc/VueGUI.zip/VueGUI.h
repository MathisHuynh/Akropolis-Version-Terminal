#pragma once
#include "Vue.h"
#include <Qlabel>
#include <QMainWindow>


class ScoreWidget : public QWidget {
    Q_OBJECT

public:
    explicit ScoreWidget(QWidget* parent = nullptr);

    // Met � jour les scores et reconstruit l'affichage
    void setScores(const std::map<std::string, size_t>& scores);

private:
    QVBoxLayout* mainLayout;
    QWidget* container;
    QGridLayout* scoreLayout;

    // Nettoie le layout avant de redessiner
    void clearLayout();

    void paintEvent(QPaintEvent* event);
};

class GUIcontroler : public QWidget {
    Q_OBJECT
public:
    //GUIcontroler(std::map<Coord, Case> cite, std::vector<std::map<Coord, const Hex*>> tuiles, std::map<std::string, size_t> dataScores, QWidget* parent = nullptr); //AJOUTER PARTIE
    GUIcontroler(Partie* p, QWidget* parent);

    void setScores(std::map<std::string, size_t> dataScores) { scores->setScores(dataScores); }
    void setPlateau(std::map<Coord, Case> grid, std::map<Coord, const Hex*> over = {}) { plateau->setPlateau(grid, over); }
    void setChantier(std::vector<std::map<Coord, const Hex*>> tuiles) {
        chantier->setChantier(tuiles);
        chantier->update();
        chantier->updateGeometry();
    }
    void setJoueurActuel(Joueur* joueur) { joueurActuel = joueur; }

    void reinitialiserChoix() { indexSelectionne = -1; plateau->setAncrage(std::nullopt); }

    friend class VueGUI;


    void keyPressEvent(QKeyEvent* event);

signals:
    void tourTermine();

private slots:
    void onPlateauClicked(Coord c);
    void onTuileSelectionnee(size_t index, Coord pivot);

private:
    size_t getIndex() { return indexSelectionne; }
    std::optional<Coord> getAncrage() {
        if (plateau->getAncrage()) return *plateau->getAncrage();
        else return std::nullopt;
    }
    std::vector<std::map<Coord, const Hex*>> getTuiles();

    bool rotation();
    void setCentre(size_t idx, Coord pivot) {partie->getChantier()[idx]->setCentre(pivot); }

    int indexSelectionne = -1; // -1 signifie aucune s�lection
    Coord pivotSelectionne;

    ChantierWidget* chantier;
    PlateauWidget* plateau;
    ScoreWidget* scores;
	QVBoxLayout* layout;
	QWidget* topBar;
	QHBoxLayout* topBarLayout;

    Partie* partie;
    Joueur* joueurActuel;
};


class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(QWidget* parent = nullptr) : QMainWindow(parent) {
        setWindowTitle("Akropolis");
        resize(1200, 800);
    }
};

class VueGUI : public Vue {
    // �tat de la machine � �tats
    enum class Etape { ChoisirPivot, ChoisirCase, ChoisirRotation };
    Etape etape = Etape::ChoisirPivot; //Choisir pivot et choisir tuile sont entrem�l�es

    // Donn�es de s�lection temporaires
    size_t tuile;
    Coord pivot;
    Coord pos;
    GUIcontroler* controler;
    MainWindow* mainWindow;

    std::map<std::string, size_t> getScores();
    void initControler();
public:
    ~VueGUI();
    VueGUI();
    std::vector<std::map<Coord, const Hex*>> getTuiles();
    void tour(JoueurHumain& joueur);
    void jouer();
};

