#include "VueGUI.h"
#include <QScrollArea>
#include <QStyleOption>
#include <QPainter>
#include <QEventLoop>
#include <QKeyEvent>

// =====================================================================================
//                                   SCORE WIDGET
// =====================================================================================

// --- CONSTRUCTEUR ---
ScoreWidget::ScoreWidget(QWidget* parent) : QWidget(parent) {
    mainLayout = new QVBoxLayout(this);

    QLabel* title = new QLabel("Tableau des Scores", this);
    title->setAlignment(Qt::AlignCenter);
    QFont titleFont = title->font();
    titleFont.setBold(true);
    titleFont.setPointSize(12);
    title->setFont(titleFont);
    mainLayout->addWidget(title);

    QScrollArea* scrollArea = new QScrollArea(this);
    container = new QWidget();
    scoreLayout = new QGridLayout(container);

    scrollArea->setWidget(container);
    scrollArea->setWidgetResizable(true);
    mainLayout->addWidget(scrollArea);
}

// --- AFFICHAGE ET MISE A JOUR ---
void ScoreWidget::paintEvent(QPaintEvent* event) {
    QStyleOption opt;
    opt.initFrom(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
}

void ScoreWidget::setScores(const std::map<std::string, size_t>& scores) {
    clearLayout();

    std::vector<std::pair<std::string, size_t>> sortedScores(scores.begin(), scores.end());
    std::sort(sortedScores.begin(), sortedScores.end(), [](const auto& a, const auto& b) {
        return a.second > b.second;
        });

    int row = 0;
    for (auto const& [nom, score] : sortedScores) {
        QString nomQt = QString::fromUtf8(nom.c_str()).trimmed();

        QLabel* nameLabel = new QLabel(nomQt, container);
        QLabel* scoreLabel = new QLabel(QString::number(score), container);

        scoreLabel->setAlignment(Qt::AlignRight | Qt::AlignVCenter);

        scoreLayout->addWidget(nameLabel, row, 0, Qt::AlignLeft);
        scoreLayout->addWidget(scoreLabel, row, 1, Qt::AlignRight);
        row++;
    }
    scoreLayout->setColumnStretch(0, 1);
    scoreLayout->setColumnStretch(1, 0);
    scoreLayout->setRowStretch(row, 1);
}

// --- NETTOYAGE ---
void ScoreWidget::clearLayout() {
    // S�curit� 1 : Si le pointeur est nul, on ne fait rien
    if (scoreLayout == nullptr) {
        qDebug() << "\nWarning: ScoreWidget non encore initialise.";
        return;
    }

    // S�curit� 2 : On vide le layout
    // takeAt(0) renverra nullptr si le layout est d�j� vide
    while (QLayoutItem* item = scoreLayout->takeAt(0)) {
        if (QWidget* widget = item->widget()) {
            widget->hide(); // On le cache pour �viter les artefacts visuels
            widget->deleteLater(); // Suppression propre par Qt
        }
        delete item; // On supprime l'item (pas le widget)
    }
}

// =====================================================================================
//                                   GUICONTROLER
// =====================================================================================

// --- CONSTRUCTEUR ---

GUIcontroler::GUIcontroler(Partie* p, QWidget* parent)
    : QWidget(parent),
    partie(p),
    joueurActuel(nullptr),
    indexSelectionne(-1)
{
    // 1. Layout Principal (Vertical)
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(15, 15, 15, 15);
    mainLayout->setSpacing(20);

    // 2. Cr�ation de la TOP BAR (Horizontale)
    // C'est ici qu'on g�re le ratio 5/6 et 1/6
    QHBoxLayout* topBarLayout = new QHBoxLayout();

    chantier = new ChantierWidget({}, this);
    scores = new ScoreWidget(this); // INITIALISATION CRITIQUE ICI

    // On ajoute les widgets au layout horizontal avec les facteurs d'�tirement (stretch)
    topBarLayout->addWidget(chantier, 5); // 5 parts
    topBarLayout->addWidget(scores, 1);   // 1 part

    // 3. Cr�ation du Plateau
    plateau = new PlateauWidget({}, {}, this);

    // 4. Assemblage dans le Main Layout
    mainLayout->addLayout(topBarLayout, 2); // La barre du haut prend moins de place
    mainLayout->addWidget(plateau, 5);      // Le plateau prend la majorit� de la hauteur

    // 5. Connexions des signaux
    connect(chantier, &ChantierWidget::tuileSelectionnee, this, &GUIcontroler::onTuileSelectionnee);
    connect(plateau, &PlateauWidget::caseClicked, this, &GUIcontroler::onPlateauClicked);

    // 6. �tat initial
    plateau->setEnabled(false);
}

std::vector<std::map<Coord, const Hex*>> GUIcontroler::getTuiles() {
    std::vector<std::map<Coord, const Hex*>> res;
    for (const auto& tuile : partie->getChantierRead()) {
        std::map<Coord, const Hex*> t;
        for (const auto& pair : tuile->getHexs()) {
            t[pair.first] = pair.second;
        }
        res.push_back(t);
    }
    return res;
}


bool GUIcontroler::rotation() {
    if (indexSelectionne == -1 || !plateau->getAncrage().has_value()) return false;

    Coord pos = *plateau->getAncrage();
    auto& tuile = partie->getChantier()[indexSelectionne];
    const Cite& cite = joueurActuel->getCite();

    // On teste les 6 orientations possibles (la rotation actuelle + les 5 suivantes)
    for (int i = 0; i < 6; ++i) {
        tuile->rotation(true); // On tourne
        if (cite.coupLegal(tuile, pos)) {
            // On a trouv� une position l�gale !
            plateau->setPlateau(cite.getPlateau(), getTuiles()[indexSelectionne]);
            return true;
        }
    }
    return false; // Aucune des 6 positions n'est l�gale
}

void GUIcontroler::onTuileSelectionnee(size_t index, Coord pivot) {
    this->indexSelectionne = index;
    setCentre(index, pivot);
    if (getAncrage() && !joueurActuel->getCite().coupLegal(partie->getChantier()[indexSelectionne], *getAncrage())) if(!rotation());


    // On peut rafra�chir le chantier si besoin
    setChantier(getTuiles());

    plateau->setEnabled(true);
    // Ici aussi, on prend les donn�es fra�ches
    plateau->setPlateau(plateau->getGrid(), getTuiles()[indexSelectionne]);
    update();
}

void GUIcontroler::onPlateauClicked(Coord coordPlateau) {
    if (indexSelectionne == -1 || joueurActuel == nullptr) return;

    auto& tuile = partie->getChantier()[indexSelectionne];
    const Cite& cite = joueurActuel->getCite();

    // Sauvegarde de l'ancien �tat
    std::optional<Coord> lastAncrage = plateau->getAncrage();

    // CAS 1 : Rotation sur place
    if (lastAncrage == coordPlateau) {
        rotation(); // On tente de tourner
    }
    // CAS 2 : Tentative de d�placement
    else {
        // On d�place l'ancrage temporairement pour tester
        plateau->setAncrage(coordPlateau);

        // Si la position actuelle n'est pas l�gale, on tente de faire pivoter la tuile
        // pour voir si elle "rentre" dans cette nouvelle case.
        bool possible = false;
        if (cite.coupLegal(tuile, coordPlateau)) {
            possible = true;
        }
        else {
            // On appelle notre nouvelle fonction rotation qui cherche un coup l�gal
            possible = rotation();
        }

        // Si apr�s tentatives, ce n'est toujours pas l�gal : on annule tout
        if (!possible) {
            plateau->setAncrage(lastAncrage); // On remet l'ancien ancrage
            // Note : la tuile a fait 6 rotations, elle est revenue � son �tat initial
        }
    }

    // Mise � jour finale du visuel
    plateau->setPlateau(cite.getPlateau(), getTuiles()[indexSelectionne]);
    plateau->update();
}

void GUIcontroler::keyPressEvent(QKeyEvent* event) {
    if (event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter) {
        auto ancrage = plateau->getAncrage();
        if (indexSelectionne != -1 && ancrage.has_value()) {
            auto& tuile = partie->getChantier()[indexSelectionne];
            if (joueurActuel->getCite().coupLegal(tuile, *ancrage)) emit tourTermine();
        }
    }
}



// =====================================================================================
//                                      VUE GUI
// =====================================================================================

void VueGUI::initControler() {
    mainWindow = new MainWindow();
    controler = new GUIcontroler(partie.get(), mainWindow);

    mainWindow->setCentralWidget(controler);
    mainWindow->show();
}

VueGUI::~VueGUI() {
    if (mainWindow) {
        delete mainWindow;
        mainWindow = nullptr;
    }
}

// Constructeur de test
VueGUI::VueGUI() {
    // 1. Cr�ation des donn�es (Mathis + IA)
    std::vector<JoueurPtr> x;
    x.emplace_back(JoueurPtr(new JoueurHumain("Mathis", 1)));
    x.emplace_back(JoueurPtr(new IllustreArchitecte(NiveauDifficulte::Hippodamos)));

    std::vector<ReglePtr> y;
    for (const auto& c : Couleurs) {
        if (c == Couleur::blanc) continue;
        y.emplace_back(RegleFactory::creer(c, false));
    }

    partie = std::unique_ptr<Partie>(new Partie(x, y, false));

    // 2. Initialisation de la fen�tre Qt
    mainWindow = new MainWindow();

    // 3. Initialisation du contr�leur via l'Adapter
    initControler();
}


// --- RECUPERATION DES DONNEES ---
std::map<std::string, size_t> VueGUI::getScores() {
    std::map<std::string, size_t> res;
    for (const auto& joueur : getJoueursRead()) {
        res[joueur->getNom()] = joueur->getScore();
    }
    return res;
}

std::vector<std::map<Coord, const Hex*>> VueGUI::getTuiles() {
    std::vector<std::map<Coord, const Hex*>> res;
    for (const auto& tuile : getChantierRead()) {
        std::map<Coord, const Hex*> t;
        for (const auto& pair : tuile->getHexs()) {
            t[pair.first] = pair.second;
        }
        res.push_back(t);
    }
    return res;
}


// --- LOGIQUE DU TOUR ---
void VueGUI::tour(JoueurHumain& joueur) {
    // L'Adapter pr�pare le terrain pour le joueur sp�cifique
    controler->setJoueurActuel(&joueur);
    controler->setChantier(getTuiles());
    controler->setPlateau(joueur.getCite().getPlateau());
    controler->setScores(getScores());

    // On d�verrouille les interactions
    controler->plateau->setEnabled(false); // Sera activ� apr�s choix d'une tuile
    controler->chantier->setEnabled(true);

    // BLOCAGE DU MOTEUR (Attente de l'utilisateur)
    QEventLoop loop;
    QObject::connect(controler, &GUIcontroler::tourTermine, &loop, &QEventLoop::quit);
    loop.exec();
    coup(joueur, controler->indexSelectionne, *controler->getAncrage());
    controler->reinitialiserChoix();
    // Une fois la boucle quitt�e, le tour est valid� et on rend la main au moteur
}

void VueGUI::jouer() {
    if (!mainWindow) initControler();
    while (!partie->piocheVide()) {
        QCoreApplication::processEvents();
        partie->jouerTour(*this);
        controler->update();
    }
    qDebug() << "\ncaca";
    // � la fin, ne fermez pas tout de suite !
     mainWindow->setWindowTitle("Partie Termin�e !");
}